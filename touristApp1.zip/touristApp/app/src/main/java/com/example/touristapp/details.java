package com.example.touristapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class details extends AppCompatActivity {
    MyDatabase db=null;
    AttractionDao attractionDao=null;

    TextView tvphone;
    TextView tvWebsite;
    RatingBar ratingBar;

    Attractions att;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        db = MyDatabase.getDatabase(getApplicationContext());
        attractionDao = db.attractionDao();

        // get the id from the intent
        Intent i = getIntent();
        String attname = i.getStringExtra("attName");

        att = attractionDao.findByName(attname);
        if (att == null) {
            Toast.makeText(this, "Invalid", Toast.LENGTH_SHORT).show();
        }
        else {

            TextView tvName=findViewById(R.id.head);
            tvName.setText(att.name);
            tvphone=findViewById(R.id.tvPhone);
            tvphone.setText(att.phone);
            tvWebsite=findViewById(R.id.tvWebsite);
            tvWebsite.setText(att.website);
            TextView tvDetail=findViewById(R.id.tvDetails);
            tvDetail.setText(att.details);
            ImageView img=findViewById(R.id.imageView);
            img.setImageResource(att.imageFile);
            ratingBar=findViewById(R.id.ratingBar);

        }

        tvWebsite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri website = Uri.parse(att.website);
                Intent intent= new Intent(Intent.ACTION_VIEW);
                intent.setData(website);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });
        tvphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ph=att.phone;
                Uri phoneNumber=Uri.parse("tel:"+ph);
                Intent i = new Intent(Intent.ACTION_DIAL);
                if (i.resolveActivity(getPackageManager()) != null) {
                    startActivity(i);
                }
            }
        });
    }


    public void back(View view){
        String rating=String.valueOf(ratingBar.getRating());
        Toast.makeText(this, "Star"+rating, Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this, listview.class);
        startActivity(i);
    }
    public void outPressed(View view){
        SharedPreferences sp3 =getSharedPreferences("my-shared-preferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sp3.edit();
        editor.clear();
        editor.commit();
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        Toast.makeText(this, "Logged Out", Toast.LENGTH_SHORT).show();
    }
}