package com.example.touristapp;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
@Dao
public interface UserDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    public void insert(User u);

    // Find an employee by email
    @Query("SELECT * FROM users WHERE email=:emailAddress")
    public User findUserByEmail(String emailAddress);
}
