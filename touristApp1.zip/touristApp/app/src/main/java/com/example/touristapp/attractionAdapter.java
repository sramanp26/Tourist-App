package com.example.touristapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class attractionAdapter extends ArrayAdapter<Attractions> {

    public attractionAdapter(Context context, ArrayList<Attractions> attraction) {
        super(context, 0, attraction);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Attractions att = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.details_row_ayout, parent, false);
        }

        TextView tvName = (TextView) convertView.findViewById(R.id.tvName);
        TextView tvAdd = (TextView) convertView.findViewById(R.id.tvAdd);
        ImageView ivPlaces =convertView.findViewById(R.id.ivPlaces);

        tvName.setText(att.name);
        tvAdd.setText(att.address);
        ivPlaces.setImageResource(att.imageFile);

        return convertView;
    }
}
