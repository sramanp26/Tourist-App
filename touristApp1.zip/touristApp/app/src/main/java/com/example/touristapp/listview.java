package com.example.touristapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class listview extends AppCompatActivity {
    MyDatabase db = null;
    AttractionDao attractionDao = null;

    ArrayList<Attractions> attractionList = new ArrayList<Attractions>();
    attractionAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);
        db = MyDatabase.getDatabase(getApplicationContext());
        attractionDao = db.attractionDao();

        attractionList = (ArrayList<Attractions>) attractionDao.getAllAttractions();
        adapter = new attractionAdapter(this, attractionList);
        ListView lv = findViewById(R.id.lvAttractions);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Attractions a = attractionList.get(i);
                String name = a.name;

                Intent intent = new Intent(getApplicationContext(), details.class);
                intent.putExtra("attName", name);
                startActivity(intent);
            }
        });
    }
    public void backPressed(View view){
        Intent i = new Intent(this, home.class);
        startActivity(i);
    }
}