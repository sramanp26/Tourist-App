package com.example.touristapp;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName ="attractions")
public class Attractions {
    @PrimaryKey
    @NonNull
    public String name;
    public String address;
    public int imageFile;
    public String phone;
    public String details;
    public String website;


    public Attractions(@NonNull String name, String address, int imageFile, String phone, String details, String website) {
        this.name = name;
        this.address = address;
        this.imageFile = imageFile;
        this.phone = phone;
        this.details = details;
        this.website = website;
    }

    @Override
    public String toString() {
        return "Attractions{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", imageFile='" + imageFile + '\'' +
                ", phone=" + phone +
                ", details='" + details + '\'' +
                ", website='" + website + '\'' +
                '}';
    }
}
