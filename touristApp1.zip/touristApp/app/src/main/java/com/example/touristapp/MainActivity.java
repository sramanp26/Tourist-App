package com.example.touristapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    MyDatabase db = null;
    UserDao userDao = null;
    AttractionDao attractionDao = null;
    EditText etEmail;
    EditText etPassword;
    CheckBox checkBox;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = MyDatabase.getDatabase(getApplicationContext());
        userDao = db.userDao();
        attractionDao = db.attractionDao();
        sp = getSharedPreferences("my-shared-preferences", Context.MODE_PRIVATE);
        etEmail=findViewById(R.id.etEmail);
        etPassword=findViewById(R.id.etPassword);
        checkBox=findViewById(R.id.checkBox);

        if(sp.contains("name")){
            String user =  sp.getString("name","");
            etEmail.setText(user);
        }
        if(sp.contains("name")){
            String pass =  sp.getString("passcode","");
            etPassword.setText(pass);
        }
    }
    public void loginPressed(View v){
        String email=etEmail.getText().toString();
        String password=etPassword.getText().toString();
        User u=userDao.findUserByEmail(email);
        if(u==null){
            Toast.makeText(this, "Invalid", Toast.LENGTH_SHORT).show();
        }
        else{
            if(u.password.equals(password)) {
                if(checkBox.isChecked()){
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("name",email);
                    editor.putString("passcode",password);
                    editor.apply();
                    Toast.makeText(this, "Checked", Toast.LENGTH_SHORT).show();

                }
                Intent i = new Intent(this, home.class);
                startActivity(i);

            }
            else{
                Toast.makeText(this, "Invalid Password", Toast.LENGTH_SHORT).show();
            }
        }

    }
    public void loadData(View view){
        userDao.insert(new User("thanos","5555"));
        userDao.insert(new User("wonderwoman","abcd"));

        attractionDao.insert(new Attractions("Golden Temple","Golden Temple Rd, Atta Mandi, Katra Ahluwalia, Amritsar, Punjab 143006, India",R.drawable.golden,"+91 183 255 3957","The Golden Temple, also known as Harmandir Sahib, meaning \"abode of God\" or Darbār Sahib, meaning \"exalted court\", is a gurdwara located in the city of Amritsar, Punjab, India. It is the preeminent spiritual site of Sikhism.","https://www.goldentempleamritsar.org/"));
        attractionDao.insert(new Attractions("Virasat-E-Khalsa","Anandgarh - Kesgarh Road, Near Qila, Khalsa Heritage Memorial Complex, Anandpur Sahib, Punjab 140118, India",R.drawable.virasat,"+91 188 723 2592","Virasat-e-Khalsa is a museum of Sikhism, located in the holy town, Anandpur Sahib, near Chandigarh, the capital of the state of Punjab, India. The museum celebrates 500 years of the Sikh history and the 300th anniversary of the birth of Khalsa, based on the scriptures written by the tenth and last human guru, Guru Gobind Singh Ji.","https://virasat-e-khalsa.net/"));
        attractionDao.insert(new Attractions("Jallianwala Bagh","Golden Temple Rd, Amritsar, Punjab, India",R.drawable.bagh,"0183-2292583","Jallianwala Bagh is a historic garden and ‘memorial of national importance’ in Amritsar, India, preserved in the memory of those wounded and killed in the Jallianwala Bagh Massacre that occurred on the site on the festival of Baisakhi, 13 April 1919. It houses a museum, gallery and a number of memorial structures.","https://en.wikipedia.org/wiki/Jallianwala_Ba"));

    }
}