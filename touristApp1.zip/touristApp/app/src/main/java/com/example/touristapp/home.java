package com.example.touristapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class home extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

    }
    public void attractionPressed(View view){
        Intent i = new Intent(this, listview.class);
        startActivity(i);
    }
    public void favouritePressed(View view){

    }
    public void clearPressed(View view){

    }
    public void logoutPressed(View view){
        SharedPreferences sp2 =getSharedPreferences("my-shared-preferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sp2.edit();
        editor.clear();
        editor.commit();
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        Toast.makeText(this, "Logged Out", Toast.LENGTH_SHORT).show();
    }
}